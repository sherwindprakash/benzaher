<template>
  <div class="products-&-services">
    <router-view />
  </div>
</template>
