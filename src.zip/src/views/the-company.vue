<template>
  <div class="the-company">
    <router-view />
  </div>
</template>
