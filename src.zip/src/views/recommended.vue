<template>
  <div class="recommended">
    <router-view />
  </div>
</template>
