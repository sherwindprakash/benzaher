<template>
<div class="SearchBIN">
  <h5>Search</h5>
</div>
</template>

<style scoped>
.SearchBIN {
  height: 100%;
  max-width: 1280px;
  margin: auto;
  padding-top: 140px;
  padding-bottom: 50px;
  padding-left: 20px;
  padding-right: 20px;
}
</style>
